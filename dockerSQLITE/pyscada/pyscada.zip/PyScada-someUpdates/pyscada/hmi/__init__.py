# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from pyscada import core


__version__ = core.__version__
__author__ = core.__author__
