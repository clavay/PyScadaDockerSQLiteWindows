Phant Installation
==================

add the following line to the urls.py:

::

   url(r'^', include('pyscada.phant.urls')),


