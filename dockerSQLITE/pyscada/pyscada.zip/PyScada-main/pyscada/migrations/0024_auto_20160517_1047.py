# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("pyscada", "0023_auto_20160314_1817"),
    ]

    operations = [
        migrations.AlterField(
            model_name="log",
            name="id",
            field=models.BigIntegerField(serialize=False, primary_key=True),
        ),
    ]
