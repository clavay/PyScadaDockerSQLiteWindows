PyScada Modbus Extension
========================

This is a extension for PyScada to support Modbus devices.


What is Working
---------------

 - Modbus TCP/IP
 - Modbus RTU

What is not Working/Missing
---------------------------

 - Documentation


Installation
------------

 - pip install pyscada-modbus


Contribute
----------

 - Issue Tracker: https://github.com/pyscada/PyScada-modbus/issues
 - Source Code: https://github.com/pyscada/PyScada-modbus


License
-------

The project is licensed under the _GNU AFFERO GENERAL PUBLIC LICENSE Version 3 (AGPLv3)_.

