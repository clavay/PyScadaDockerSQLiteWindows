# -*- coding: utf-8 -*-
from __future__ import unicode_literals

__version__ = "0.8.1"
__author__ = "Camille Lavayssiere"
__email__ = "team@pyscada.org"
__description__ = "Operations extension for PyScada a Python and Django based Open Source SCADA System"
__app_name__ = "Operations"

PROTOCOL_ID = 18

additional_installed_app = ["pyscada.aggregation"]
